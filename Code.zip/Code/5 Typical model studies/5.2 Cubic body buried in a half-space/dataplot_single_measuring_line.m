% -------------------------------------------------------------------------------
% This code is used select data for a single measuring line.
% The output files can be used to produce the manuscript's figures.
% -------------------------------------------------------------------------------
clc;
clear all;

% Select a measuring line
cexian = 0;

% Load data processed by the file 'dataplot_surfer.m' 
% Note: Delete the first line in the data file before loading
di_temp=load('Cubic body.dat');

% Extract the data of the specified measuring line
x=di_temp(:,1);
y=di_temp(:,2);
z=di_temp(:,3);
cexian_position = find(y==cexian);
di_y_0=di_temp(cexian_position,:);

% Write data to files
fid1 = fopen('Cubic body_y=0.dat','w');
    
fprintf(fid1,'%s \n',['x y z amp_ex amp_ey amp_ez amp_hx amp_hy amp_hz amp_e amp_h ',...
                      'ph_ex ph_ey ph_ez ph_hx ph_hy ph_hz']);
       
for j=1:length(cexian_position)
    
    fprintf(fid1,'%f %f %f %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e\n',...
           di_y_0(j,:)); 
   
end
fclose(fid1);


