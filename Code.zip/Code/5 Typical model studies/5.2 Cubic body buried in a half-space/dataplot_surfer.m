% -------------------------------------------------------------------------------
% This code is used for data post-processing for the model of a buried cubic body.
% The output files can be used to produce the manuscript's figures.
% -------------------------------------------------------------------------------
clc;
clear all;

% Load raw data for the model of a buried cubic body calculated by our 3D algorithm
di_temp=load('Cubic body buried in a half-space.txt');
% Load raw data for the half-space model calculated by our 3D algorithm
jun_temp=load('Half-space.txt');

% Data processing
miu0=pi*4e-07; % Permeability of the free space
di=[di_temp(:,1:3),di_temp(:,4:9),di_temp(:,10:15)/miu0];
jun=[jun_temp(:,1:3),jun_temp(:,4:9),jun_temp(:,10:15)/miu0];

% Calculate amplitude and phase
amp_di=sqrt([di(:,4).^2+di(:,5).^2,di(:,6).^2+di(:,7).^2,di(:,8).^2+di(:,9).^2,...
             di(:,10).^2+di(:,11).^2,di(:,12).^2+di(:,13).^2,di(:,14).^2+di(:,15).^2,...
             di(:,4).^2+di(:,5).^2+di(:,6).^2+di(:,7).^2+di(:,8).^2+di(:,9).^2,...
             di(:,10).^2+di(:,11).^2+di(:,12).^2+di(:,13).^2+di(:,14).^2+di(:,15).^2]);

amp_jun=sqrt([jun(:,4).^2+jun(:,5).^2,jun(:,6).^2+jun(:,7).^2,jun(:,8).^2+jun(:,9).^2,...
              jun(:,10).^2+jun(:,11).^2,jun(:,12).^2+jun(:,13).^2,jun(:,14).^2+jun(:,15).^2,...
              jun(:,4).^2+jun(:,5).^2+jun(:,6).^2+jun(:,7).^2+jun(:,8).^2+jun(:,9).^2,...
              jun(:,10).^2+jun(:,11).^2+jun(:,12).^2+jun(:,13).^2+jun(:,14).^2+jun(:,15).^2]);

ph_di=rad2deg([atan2(di(:,5),di(:,4)),atan2(di(:,7),di(:,6)),atan2(di(:,9),di(:,8)),...
               atan2(di(:,11),di(:,10)),atan2(di(:,13),di(:,12)),atan2(di(:,15),di(:,14))]);

ph_jun=rad2deg([atan2(jun(:,5),jun(:,4)),atan2(jun(:,7),jun(:,6)),atan2(jun(:,9),jun(:,8)),...
               atan2(jun(:,11),jun(:,10)),atan2(jun(:,13),jun(:,12)),atan2(jun(:,15),jun(:,14))]);  
% Calculate the amplitude relative difference and phase difference
error_amp_di=100*(amp_di-amp_jun)./amp_jun;
error_ph_di=ph_di-ph_jun;

% Coordinate information
x=di(:,1);
y=di(:,2);
z=di(:,3);

% Write data to files
fid1 = fopen('Cubic body.dat','w');
fid3 = fopen('Half-space.dat','w');
fid4 = fopen('Differences.dat','w');
    
fprintf(fid1,'%s \n',['x y z amp_ex amp_ey amp_ez amp_hx amp_hy amp_hz amp_e amp_h ',...
                      'ph_ex ph_ey ph_ez ph_hx ph_hy ph_hz']);
fprintf(fid3,'%s \n',['x y z amp_ex amp_ey amp_ez amp_hx amp_hy amp_hz amp_e amp_h ',...
                      'ph_ex ph_ey ph_ez ph_hx ph_hy ph_hz']);
fprintf(fid4,'%s \n',['x y z amp_ex amp_ey amp_ez amp_hx amp_hy amp_hz amp_e amp_h ',...
                      'ph_ex ph_ey ph_ez ph_hx ph_hy ph_hz']);
       
for j=1:size(x)
    
   fprintf(fid1,'%f %f %f %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e\n',...
           [x(j),y(j),z(j),amp_di(j,:),ph_di(j,:)]); 
   fprintf(fid3,'%f %f %f %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e\n',...
           [x(j),y(j),z(j),amp_jun(j,:),ph_jun(j,:)]); 
   fprintf(fid4,'%f %f %f %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e\n',...
           [x(j),y(j),z(j),error_amp_di(j,:),error_ph_di(j,:)]); 
end
fclose(fid1);
fclose(fid3);
fclose(fid4);



