% -------------------------------------------------------------------------------
% This code is used to calculate the time-domain responses.
% The output files can be used to produce the manuscript's figures.
% -------------------------------------------------------------------------------
clc;
clear all;

% time series
t = linspace(0,0.06,1000);

% Set a measuring line and observation points
cexian = 0;
cedian = [40,200,680,1000,1320];

% Angular frequency
w = 2*pi*50;

% Load raw data in the frequency domain
di_temp=load('Cubic body buried in a half-space.txt');

% Data processing
miu0=pi*4e-07;
di=[di_temp(:,1:3),di_temp(:,4:9),di_temp(:,10:15)/miu0];

% Extract the data of the specified measuring line and observation points 
x=di(:,1);
y=di(:,2);
z=di(:,3);
cexian_position = find(y==cexian);
cedian_position = [];
for i=1:length(cedian)
    cedian_position = [cedian_position,find(x(cexian_position)==cedian(i))];
end
cedian_position = cexian_position(cedian_position);

% Calculate the time-domain responses
ey = [];
hx = [];
hz = [];
for i=1:length(cedian)
    ey(i,:)=imag((di(cedian_position(i),6)+1i*di(cedian_position(i),7))*exp(1i*w*t));
    hx(i,:)=imag((di(cedian_position(i),10)+1i*di(cedian_position(i),11))*exp(1i*w*t));
    hz(i,:)=imag((di(cedian_position(i),14)+1i*di(cedian_position(i),15))*exp(1i*w*t));
end


% Write data to files
fid1 = fopen('Cubic body_y=0_ey.dat','w');
fid2 = fopen('Cubic body_y=0_hx.dat','w');
fid3 = fopen('Cubic body_y=0_hz.dat','w');
    
fprintf(fid1,'%s \n',['t     ','point_x=',num2str(cedian(1)),'     point_x=',num2str(cedian(2)),...
                      '     point_x=',num2str(cedian(3)),'     point_x=',num2str(cedian(4)),...
                      '     point_x=',num2str(cedian(5))]);
                  
fprintf(fid2,'%s \n',['t     ','point_x=',num2str(cedian(1)),'     point_x=',num2str(cedian(2)),...
                      '     point_x=',num2str(cedian(3)),'     point_x=',num2str(cedian(4)),...
                      '     point_x=',num2str(cedian(5))]);
fprintf(fid3,'%s \n',['t     ','point_x=',num2str(cedian(1)),'     point_x=',num2str(cedian(2)),...
                      '     point_x=',num2str(cedian(3)),'     point_x=',num2str(cedian(4)),...
                      '     point_x=',num2str(cedian(5))]);
       
for j=1:length(t)
    
   fprintf(fid1,'%15f %15.8e %15.8e %15.8e %15.8e %15.8e\n',...
           [t(j),ey(:,j)']); 
   fprintf(fid2,'%15f %15.8e %15.8e %15.8e %15.8e %15.8e\n',...
           [t(j),hx(:,j)']); 
   fprintf(fid3,'%15f %15.8e %15.8e %15.8e %15.8e %15.8e\n',...
           [t(j),hz(:,j)']); 
   
end
fclose(fid1);
fclose(fid2);
fclose(fid3);

