% -------------------------------------------------------------------
% This code is used for data post-processing for 1D algorithm testing.
% The output files can be used to produce the manuscript's figures. 
% -------------------------------------------------------------------

clc;
clear all;

% Load raw data calculated by our 1D algorithm
gyx1D_temp=load('Our 1D algorithm.txt');

% Load raw data calculated by Dipole1D
gyxdi_temp=load('Dipole1D.txt');
% Data processing
miu0=pi*4e-07; % Permeability of the free space
x=gyx1D_temp(:,2);
gyx1D=gyx1D_temp(:,4:end);
gyxdi=[gyxdi_temp(:,1:6),gyxdi_temp(:,7:12)./miu0]; % Calculate H

% Calculate amplitude
amp_1d=sqrt([gyx1D(:,1).^2+gyx1D(:,2).^2,gyx1D(:,3).^2+gyx1D(:,4).^2,gyx1D(:,5).^2+gyx1D(:,6).^2,...
             gyx1D(:,7).^2+gyx1D(:,8).^2,gyx1D(:,9).^2+gyx1D(:,10).^2,gyx1D(:,11).^2+gyx1D(:,12).^2,...
             gyx1D(:,1).^2+gyx1D(:,2).^2+gyx1D(:,3).^2+gyx1D(:,4).^2+gyx1D(:,5).^2+gyx1D(:,6).^2,...
             gyx1D(:,7).^2+gyx1D(:,8).^2+gyx1D(:,9).^2+gyx1D(:,10).^2+gyx1D(:,11).^2+gyx1D(:,12).^2]);
amp_di=sqrt([gyxdi(:,1).^2+gyxdi(:,2).^2,gyxdi(:,3).^2+gyxdi(:,4).^2,gyxdi(:,5).^2+gyxdi(:,6).^2,...
             gyxdi(:,7).^2+gyxdi(:,8).^2,gyxdi(:,9).^2+gyxdi(:,10).^2,gyxdi(:,11).^2+gyxdi(:,12).^2,...
             gyxdi(:,1).^2+gyxdi(:,2).^2+gyxdi(:,3).^2+gyxdi(:,4).^2+gyxdi(:,5).^2+gyxdi(:,6).^2,...
             gyxdi(:,7).^2+gyxdi(:,8).^2+gyxdi(:,9).^2+gyxdi(:,10).^2+gyxdi(:,11).^2+gyxdi(:,12).^2]);
% Calculate phase
ph_1d=rad2deg([atan2(gyx1D(:,2),gyx1D(:,1)),atan2(gyx1D(:,4),gyx1D(:,3)),atan2(gyx1D(:,6),gyx1D(:,5)),...
       atan2(gyx1D(:,8),gyx1D(:,7)),atan2(gyx1D(:,10),gyx1D(:,9)),atan2(gyx1D(:,12),gyx1D(:,11))]);
ph_di=rad2deg([atan2(gyxdi(:,2),gyxdi(:,1)),atan2(gyxdi(:,4),gyxdi(:,3)),atan2(gyxdi(:,6),gyxdi(:,5)),...
       atan2(gyxdi(:,8),gyxdi(:,7)),atan2(gyxdi(:,10),gyxdi(:,9)),atan2(gyxdi(:,12),gyxdi(:,11))]);
% Calculate amplitude relative errors and phase differences
error=100*abs((gyxdi-gyx1D)./gyxdi);
error_amp=100*((amp_di-amp_1d)./amp_di);
error_ph=ph_di-ph_1d;
error_ph(error_ph>350)=error_ph(error_ph>350)-360;
error_ph(error_ph<-350)=error_ph(error_ph<-350)+360;

% Write data to files
fid1=fopen(['Our 1D algorithm.dat'],'wt');
fid2=fopen(['Dipole1D.dat'],'wt');
fid3=fopen(['Relative errors and differences.dat'],'wt');
fprintf(fid1,'%s \n','x amp_ex amp_ey amp_ez amp_hx amp_hy amp_hz amp_e amp_h ph_ex ph_ey ph_ez ph_hx ph_hy ph_hz');
fprintf(fid2,'%s \n','x amp_ex amp_ey amp_ez amp_hx amp_hy amp_hz amp_e amp_h ph_ex ph_ey ph_ez ph_hx ph_hy ph_hz');
fprintf(fid3,'%s \n','x amp_ex amp_ey amp_ez amp_hx amp_hy amp_hz amp_e amp_h ph_ex ph_ey ph_ez ph_hx ph_hy ph_hz');

for j=1:size(x)
   fprintf(fid1,'%f %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e\n',...
           [x(j),amp_1d(j,:),ph_1d(j,:)]);
   fprintf(fid2,'%f %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e\n',...
           [x(j),amp_di(j,:),ph_di(j,:)]);
   fprintf(fid3,'%f %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e\n',...
           [x(j),error_amp(j,:),error_ph(j,:)]);
end
fclose(fid1);
fclose(fid2);
fclose(fid3);