% -------------------------------------------------------------------
% This code is used for data post-processing for 3D algorithm testing.
% The output files can be used to produce the manuscript's figures. 
% -------------------------------------------------------------------

clc
clear all
format long e;

% Current parameters
% Amplitude
I_amp=[1,1,1];
% Phase
I_pha=[-120,0,120];
% Current contains the amplitude and phase 
I=I_amp.*exp(1j*(I_pha*pi/180));

% Permeability of the free space
miu0=pi*4e-07;

% Load raw data calculated by Dipole1D
data1_o=load('Dipole1D_A.txt');
data2_o=load('Dipole1D_B.txt');
data3_o=load('Dipole1D_C.txt');

% Data processing
data1=[data1_o(:,1)+1j*data1_o(:,2),data1_o(:,3)+1j*data1_o(:,4),data1_o(:,5)+1j*data1_o(:,6),...
       data1_o(:,7)/miu0+1j*data1_o(:,8)/miu0,data1_o(:,9)/miu0+1j*data1_o(:,10)/miu0,data1_o(:,11)/miu0+1j*data1_o(:,12)/miu0];
data2=[data2_o(:,1)+1j*data2_o(:,2),data2_o(:,3)+1j*data2_o(:,4),data2_o(:,5)+1j*data2_o(:,6),...
       data2_o(:,7)/miu0+1j*data2_o(:,8)/miu0,data2_o(:,9)/miu0+1j*data2_o(:,10)/miu0,data2_o(:,11)/miu0+1j*data2_o(:,12)/miu0];
data3=[data3_o(:,1)+1j*data3_o(:,2),data3_o(:,3)+1j*data3_o(:,4),data3_o(:,5)+1j*data3_o(:,6),...
       data3_o(:,7)/miu0+1j*data3_o(:,8)/miu0,data3_o(:,9)/miu0+1j*data3_o(:,10)/miu0,data3_o(:,11)/miu0+1j*data3_o(:,12)/miu0];

data1=data1*I(1);
data2=data2*I(2);
data3=data3*I(3);
data=data1+data2+data3; % Superposition of responses

% Load raw data calculated by our 3D algorithm
sanwei=load('Our 3D algorithm.txt');
x=sanwei(:,1);
y=sanwei(:,2);
z=sanwei(:,3);

data_3d=[sanwei(:,4:9),sanwei(:,10:end)/miu0];
data_1d=[real(data(:,1)),imag(data(:,1)),real(data(:,2)),imag(data(:,2)),real(data(:,3)),imag(data(:,3)),...
         real(data(:,4)),imag(data(:,4)),real(data(:,5)),imag(data(:,5)),real(data(:,6)),imag(data(:,6))];
     
% Calculate amplitude
amp_3d=sqrt([data_3d(:,1).^2+data_3d(:,2).^2,data_3d(:,3).^2+data_3d(:,4).^2,data_3d(:,5).^2+data_3d(:,6).^2,...
             data_3d(:,7).^2+data_3d(:,8).^2,data_3d(:,9).^2+data_3d(:,10).^2,data_3d(:,11).^2+data_3d(:,12).^2,...
             data_3d(:,1).^2+data_3d(:,2).^2+data_3d(:,3).^2+data_3d(:,4).^2+data_3d(:,5).^2+data_3d(:,6).^2,...
             data_3d(:,7).^2+data_3d(:,8).^2+data_3d(:,9).^2+data_3d(:,10).^2+data_3d(:,11).^2+data_3d(:,12).^2]);
amp_1d=sqrt([data_1d(:,1).^2+data_1d(:,2).^2,data_1d(:,3).^2+data_1d(:,4).^2,data_1d(:,5).^2+data_1d(:,6).^2,...
             data_1d(:,7).^2+data_1d(:,8).^2,data_1d(:,9).^2+data_1d(:,10).^2,data_1d(:,11).^2+data_1d(:,12).^2,...
             data_1d(:,1).^2+data_1d(:,2).^2+data_1d(:,3).^2+data_1d(:,4).^2+data_1d(:,5).^2+data_1d(:,6).^2,...
             data_1d(:,7).^2+data_1d(:,8).^2+data_1d(:,9).^2+data_1d(:,10).^2+data_1d(:,11).^2+data_1d(:,12).^2]);
% Calculate phase
ph_3d=rad2deg([atan2(data_3d(:,2),data_3d(:,1)),atan2(data_3d(:,4),data_3d(:,3)),atan2(data_3d(:,6),data_3d(:,5)),...
       atan2(data_3d(:,8),data_3d(:,7)),atan2(data_3d(:,10),data_3d(:,9)),atan2(data_3d(:,12),data_3d(:,11))]);
ph_1d=rad2deg([atan2(data_1d(:,2),data_1d(:,1)),atan2(data_1d(:,4),data_1d(:,3)),atan2(data_1d(:,6),data_1d(:,5)),...
       atan2(data_1d(:,8),data_1d(:,7)),atan2(data_1d(:,10),data_1d(:,9)),atan2(data_1d(:,12),data_1d(:,11))]);
% Calculate amplitude relative errors and phase differences
error=100*abs((data_1d-data_3d)./data_1d);
error_amp=100*((amp_1d-amp_3d)./amp_1d);
error_ph=ph_1d-ph_3d;
error_ph(error_ph>350)=error_ph(error_ph>350)-360;
error_ph(error_ph<-350)=error_ph(error_ph<-350)+360;

% Measuring point information
xr1=-500:0.5:500;
xr2=-500:0.5:500;
yr=125;
zr=0.1;
num_x1=length(xr1);
num_x2=length(xr2);
num_y=length(yr);
num_z=length(zr);
num_polt=num_y*num_z;

% Eliminate flying-points
x_t=find((xr1>-11&xr1<-9)|(xr1>-1&xr1<1)|(xr1>9&xr1<11));
xr1_t=xr1; xr1_t(x_t)=[];
xr2_t=xr2; xr2_t(x_t)=[];
num_x1_t=length(xr1_t);
num_x2_t=length(xr1_t);
amp_1d_t=amp_1d;
amp_3d_t=amp_3d;
ph_1d_t=ph_1d;
ph_3d_t=ph_3d;
error_amp_t=error_amp;
error_ph_t=error_ph;
temp=x_t;
for i=1:num_polt-1
    temp=[temp,x_t+i*num_x1];
end
amp_1d_t(temp,:)=[];
amp_3d_t(temp,:)=[];
ph_1d_t(temp,:)=[];
ph_3d_t(temp,:)=[];
error_amp_t(temp,:)=[];
error_ph_t(temp,:)=[];

% Write data to files
for i=1:num_polt
    fid1=fopen(['Dipole1D.dat'],'wt');
    fid2=fopen(['Our 3D algorithm.dat'],'wt');
    fid3=fopen(['Relative errors and differences.dat'],'wt');
    fprintf(fid1,'%s \n','x amp_ex amp_ey amp_ez amp_hx amp_hy amp_hz amp_e amp_h ph_ex ph_ey ph_ez ph_hx ph_hy ph_hz');
    fprintf(fid2,'%s \n','x amp_ex amp_ey amp_ez amp_hx amp_hy amp_hz amp_e amp_h ph_ex ph_ey ph_ez ph_hx ph_hy ph_hz');
    fprintf(fid3,'%s \n','x amp_ex amp_ey amp_ez amp_hx amp_hy amp_hz amp_e amp_h ph_ex ph_ey ph_ez ph_hx ph_hy ph_hz');
    for m=1:num_x1_t
        fprintf(fid1,'%f %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e\n',...
                [xr1_t(m),amp_1d_t(num_x1_t*(i-1)+m,:),ph_1d_t(num_x1_t*(i-1)+m,:)]);
        fprintf(fid2,'%f %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e\n',...
                [xr1_t(m),amp_3d_t(num_x1_t*(i-1)+m,:),ph_3d_t(num_x1_t*(i-1)+m,:)]);
        fprintf(fid3,'%f %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e\n',...
                [xr1_t(m),error_amp_t(num_x1_t*(i-1)+m,:),error_ph_t(num_x1_t*(i-1)+m,:)]);
    end
    fclose(fid1);
    fclose(fid2);
    fclose(fid3);
end

