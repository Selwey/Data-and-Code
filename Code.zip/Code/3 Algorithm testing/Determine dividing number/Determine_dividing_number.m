% -------------------------------------------------------------------------------
% This code is used for data post-processing for determining the dividing number.
% The output files can be used to produce the manuscript's figures.
% -------------------------------------------------------------------------------

clc
clear all
format long e;

% Current parameters
% Amplitude
I_amp=1;
% Phase
I_pha=0;
% Current contains the amplitude and phase 
I=I_amp.*exp(1j*(I_pha*pi/180));

% Measuring point information
xr=-1000:1:1000;
yr=0;
zr=0;

% Permeability of the free space
miu0=pi*4e-07;

% Load raw data calculated by Dipole1D
fd10_o=load('10 sub-segments.txt');
fd20_o=load('20 sub-segments.txt');
fd30_o=load('30 sub-segments.txt');
fd40_o=load('40 sub-segments.txt');
fd50_o=load('50 sub-segments.txt');

% Data processing
fd10_t=[fd10_o(:,1)+1j*fd10_o(:,2),fd10_o(:,3)+1j*fd10_o(:,4),fd10_o(:,5)+1j*fd10_o(:,6),...
       fd10_o(:,7)/miu0+1j*fd10_o(:,8)/miu0,fd10_o(:,9)/miu0+1j*fd10_o(:,10)/miu0,fd10_o(:,11)/miu0+1j*fd10_o(:,12)/miu0].*I;
fd20_t=[fd20_o(:,1)+1j*fd20_o(:,2),fd20_o(:,3)+1j*fd20_o(:,4),fd20_o(:,5)+1j*fd20_o(:,6),...
       fd20_o(:,7)/miu0+1j*fd20_o(:,8)/miu0,fd20_o(:,9)/miu0+1j*fd20_o(:,10)/miu0,fd20_o(:,11)/miu0+1j*fd20_o(:,12)/miu0].*I;
fd30_t=[fd30_o(:,1)+1j*fd30_o(:,2),fd30_o(:,3)+1j*fd30_o(:,4),fd30_o(:,5)+1j*fd30_o(:,6),...
       fd30_o(:,7)/miu0+1j*fd30_o(:,8)/miu0,fd30_o(:,9)/miu0+1j*fd30_o(:,10)/miu0,fd30_o(:,11)/miu0+1j*fd30_o(:,12)/miu0].*I;
fd40_t=[fd40_o(:,1)+1j*fd40_o(:,2),fd40_o(:,3)+1j*fd40_o(:,4),fd40_o(:,5)+1j*fd40_o(:,6),...
       fd40_o(:,7)/miu0+1j*fd40_o(:,8)/miu0,fd40_o(:,9)/miu0+1j*fd40_o(:,10)/miu0,fd40_o(:,11)/miu0+1j*fd40_o(:,12)/miu0].*I;
fd50_t=[fd50_o(:,1)+1j*fd50_o(:,2),fd50_o(:,3)+1j*fd50_o(:,4),fd50_o(:,5)+1j*fd50_o(:,6),...
       fd50_o(:,7)/miu0+1j*fd50_o(:,8)/miu0,fd50_o(:,9)/miu0+1j*fd50_o(:,10)/miu0,fd50_o(:,11)/miu0+1j*fd50_o(:,12)/miu0].*I;

fd10=[real(fd10_t(:,1)),imag(fd10_t(:,1)),real(fd10_t(:,2)),imag(fd10_t(:,2)),real(fd10_t(:,3)),imag(fd10_t(:,3)),...
       real(fd10_t(:,4)),imag(fd10_t(:,4)),real(fd10_t(:,5)),imag(fd10_t(:,5)),real(fd10_t(:,6)),imag(fd10_t(:,6))];
fd20=[real(fd20_t(:,1)),imag(fd20_t(:,1)),real(fd20_t(:,2)),imag(fd20_t(:,2)),real(fd20_t(:,3)),imag(fd20_t(:,3)),...
       real(fd20_t(:,4)),imag(fd20_t(:,4)),real(fd20_t(:,5)),imag(fd20_t(:,5)),real(fd20_t(:,6)),imag(fd20_t(:,6))];
fd30=[real(fd30_t(:,1)),imag(fd30_t(:,1)),real(fd30_t(:,2)),imag(fd30_t(:,2)),real(fd30_t(:,3)),imag(fd30_t(:,3)),...
       real(fd30_t(:,4)),imag(fd30_t(:,4)),real(fd30_t(:,5)),imag(fd30_t(:,5)),real(fd30_t(:,6)),imag(fd30_t(:,6))];
fd40=[real(fd40_t(:,1)),imag(fd40_t(:,1)),real(fd40_t(:,2)),imag(fd40_t(:,2)),real(fd40_t(:,3)),imag(fd40_t(:,3)),...
       real(fd40_t(:,4)),imag(fd40_t(:,4)),real(fd40_t(:,5)),imag(fd40_t(:,5)),real(fd40_t(:,6)),imag(fd40_t(:,6))];
fd50=[real(fd50_t(:,1)),imag(fd50_t(:,1)),real(fd50_t(:,2)),imag(fd50_t(:,2)),real(fd50_t(:,3)),imag(fd50_t(:,3)),...
       real(fd50_t(:,4)),imag(fd50_t(:,4)),real(fd50_t(:,5)),imag(fd50_t(:,5)),real(fd50_t(:,6)),imag(fd50_t(:,6))];
   
% Calculate amplitude and phase
a_fd10=abs(fd10_t);
a_fd20=abs(fd20_t);
a_fd30=abs(fd30_t);
a_fd40=abs(fd40_t);
a_fd50=abs(fd50_t);

p_fd10=rad2deg([atan2(fd10(:,2),fd10(:,1)),atan2(fd10(:,4),fd10(:,3)),atan2(fd10(:,6),fd10(:,5)),...
       atan2(fd10(:,8),fd10(:,7)),atan2(fd10(:,10),fd10(:,9)),atan2(fd10(:,12),fd10(:,11))]);
p_fd20=rad2deg([atan2(fd20(:,2),fd20(:,1)),atan2(fd20(:,4),fd20(:,3)),atan2(fd20(:,6),fd20(:,5)),...
       atan2(fd20(:,8),fd20(:,7)),atan2(fd20(:,10),fd20(:,9)),atan2(fd20(:,12),fd20(:,11))]);
p_fd30=rad2deg([atan2(fd30(:,2),fd30(:,1)),atan2(fd30(:,4),fd30(:,3)),atan2(fd30(:,6),fd30(:,5)),...
       atan2(fd30(:,8),fd30(:,7)),atan2(fd30(:,10),fd30(:,9)),atan2(fd30(:,12),fd30(:,11))]);
p_fd40=rad2deg([atan2(fd40(:,2),fd40(:,1)),atan2(fd40(:,4),fd40(:,3)),atan2(fd40(:,6),fd40(:,5)),...
       atan2(fd40(:,8),fd40(:,7)),atan2(fd40(:,10),fd40(:,9)),atan2(fd40(:,12),fd40(:,11))]);
p_fd50=rad2deg([atan2(fd50(:,2),fd50(:,1)),atan2(fd50(:,4),fd50(:,3)),atan2(fd50(:,6),fd50(:,5)),...
       atan2(fd50(:,8),fd50(:,7)),atan2(fd50(:,10),fd50(:,9)),atan2(fd50(:,12),fd50(:,11))]);

% Calculate differences
error20_10=(fd20-fd10)./fd10;
error30_20=(fd30-fd20)./fd20;
error40_30=(fd40-fd30)./fd30;
error50_40=(fd50-fd40)./fd40;

a_error20_10=(a_fd20-a_fd10)./a_fd10;
a_error30_20=(a_fd30-a_fd20)./a_fd20;
a_error40_30=(a_fd40-a_fd30)./a_fd30;
a_error50_40=(a_fd50-a_fd40)./a_fd40;

p_error20_10=(p_fd20-p_fd10);
p_error30_20=(p_fd30-p_fd20);
p_error40_30=(p_fd40-p_fd30);
p_error50_40=(p_fd50-p_fd40);

% Eliminate flying-points
x_t=find(xr>-1&xr<1);
xr_t=xr; xr_t(x_t)=[];
num_x_t=length(xr_t);
error20_10_t=error20_10; error20_10_t(x_t,:)=[];
error30_20_t=error30_20; error30_20_t(x_t,:)=[];
error40_30_t=error40_30; error40_30_t(x_t,:)=[];
error50_40_t=error50_40; error50_40_t(x_t,:)=[];

a_error20_10_t=a_error20_10; a_error20_10_t(x_t,:)=[];
a_error30_20_t=a_error30_20; a_error30_20_t(x_t,:)=[];
a_error40_30_t=a_error40_30; a_error40_30_t(x_t,:)=[];
a_error50_40_t=a_error50_40; a_error50_40_t(x_t,:)=[];

p_error20_10_t=p_error20_10; p_error20_10_t(x_t,:)=[];
p_error30_20_t=p_error30_20; p_error30_20_t(x_t,:)=[];
p_error40_30_t=p_error40_30; p_error40_30_t(x_t,:)=[];
p_error50_40_t=p_error50_40; p_error50_40_t(x_t,:)=[];


% Write data to files
fid2=fopen(['20 and 10 sub-segments.dat'],'wt');
fid3=fopen(['30 and 20 sub-segments.dat'],'wt');
fid4=fopen(['40 and 30 sub-segments.dat'],'wt');
fid5=fopen(['50 and 40 sub-segments.dat'],'wt');
fprintf(fid2,'%s \n','x amp_ex amp_ey amp_ez amp_hx amp_hy amp_hz ph_ex ph_ey ph_ez ph_hx ph_hy ph_hz');
fprintf(fid3,'%s \n','x amp_ex amp_ey amp_ez amp_hx amp_hy amp_hz ph_ex ph_ey ph_ez ph_hx ph_hy ph_hz');
fprintf(fid4,'%s \n','x amp_ex amp_ey amp_ez amp_hx amp_hy amp_hz ph_ex ph_ey ph_ez ph_hx ph_hy ph_hz');
fprintf(fid5,'%s \n','x amp_ex amp_ey amp_ez amp_hx amp_hy amp_hz ph_ex ph_ey ph_ez ph_hx ph_hy ph_hz');
for m=1:num_x_t
    fprintf(fid2,'%f %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e\n',...
            [xr_t(m),a_error20_10_t(m,:),p_error20_10_t(m,:)]);
    fprintf(fid3,'%f %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e\n',...
            [xr_t(m),a_error30_20_t(m,:),p_error30_20_t(m,:)]);
    fprintf(fid4,'%f %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e\n',...
            [xr_t(m),a_error40_30_t(m,:),p_error40_30_t(m,:)]);
    fprintf(fid5,'%f %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e\n',...
            [xr_t(m),a_error50_40_t(m,:),p_error50_40_t(m,:)]);
end
fclose(fid2);
fclose(fid3);
fclose(fid4);
fclose(fid5);