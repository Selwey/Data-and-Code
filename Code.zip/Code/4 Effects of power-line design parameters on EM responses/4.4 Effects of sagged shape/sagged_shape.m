% -------------------------------------------------------------------------------
% This code is used for data post-processing for saaged shapes of power lines.
% The output files can be used to produce the manuscript's figures.
% -------------------------------------------------------------------------------
clc
clear all
format long e;

% Current parameters
% Amplitude
I_amp=[1,1,1];
% Phase
I_pha=[-120,0,120];
% Current contains the amplitude and phase 
I=I_amp.*exp(1j*(I_pha*pi/180));

% Measuring point information
xr=-10000:5:10000;
yr=0:125:250;
zr=0;

% Permeability of the free space
miu0=pi*4e-07;

% Load raw data for sagged power lines calculated by Dipole1D
data1_o=load('sagged_phase conductor_A.txt');
data2_o=load('sagged_phase conductor_B.txt');
data3_o=load('sagged_phase conductor_C.txt');
% Load raw data for straight line sources
bkl_1d=load('straight line sources.dat');
bkl_1d(:,1)=[];

% Data processing
data1=[data1_o(:,1)+1j*data1_o(:,2),data1_o(:,3)+1j*data1_o(:,4),data1_o(:,5)+1j*data1_o(:,6),...
       data1_o(:,7)/miu0+1j*data1_o(:,8)/miu0,data1_o(:,9)/miu0+1j*data1_o(:,10)/miu0,data1_o(:,11)/miu0+1j*data1_o(:,12)/miu0];
data2=[data2_o(:,1)+1j*data2_o(:,2),data2_o(:,3)+1j*data2_o(:,4),data2_o(:,5)+1j*data2_o(:,6),...
       data2_o(:,7)/miu0+1j*data2_o(:,8)/miu0,data2_o(:,9)/miu0+1j*data2_o(:,10)/miu0,data2_o(:,11)/miu0+1j*data2_o(:,12)/miu0];
data3=[data3_o(:,1)+1j*data3_o(:,2),data3_o(:,3)+1j*data3_o(:,4),data3_o(:,5)+1j*data3_o(:,6),...
       data3_o(:,7)/miu0+1j*data3_o(:,8)/miu0,data3_o(:,9)/miu0+1j*data3_o(:,10)/miu0,data3_o(:,11)/miu0+1j*data3_o(:,12)/miu0];

data1=data1*I(1);
data2=data2*I(2);
data3=data3*I(3);
data=data1+data2+data3;
% Calculate amplitude and phase
data_1d=[real(data(:,1)),imag(data(:,1)),real(data(:,2)),imag(data(:,2)),real(data(:,3)),imag(data(:,3)),...
         real(data(:,4)),imag(data(:,4)),real(data(:,5)),imag(data(:,5)),real(data(:,6)),imag(data(:,6))];
amp_1d=sqrt([data_1d(:,1).^2+data_1d(:,2).^2,data_1d(:,3).^2+data_1d(:,4).^2,data_1d(:,5).^2+data_1d(:,6).^2,...
            data_1d(:,7).^2+data_1d(:,8).^2,data_1d(:,9).^2+data_1d(:,10).^2,data_1d(:,11).^2+data_1d(:,12).^2,...
            data_1d(:,1).^2+data_1d(:,2).^2+data_1d(:,3).^2+data_1d(:,4).^2+data_1d(:,5).^2+data_1d(:,6).^2,...
            data_1d(:,7).^2+data_1d(:,8).^2+data_1d(:,9).^2+data_1d(:,10).^2+data_1d(:,11).^2+data_1d(:,12).^2]);
ph_1d=rad2deg([atan2(data_1d(:,2),data_1d(:,1)),atan2(data_1d(:,4),data_1d(:,3)),atan2(data_1d(:,6),data_1d(:,5)),...
       atan2(data_1d(:,8),data_1d(:,7)),atan2(data_1d(:,10),data_1d(:,9)),atan2(data_1d(:,12),data_1d(:,11))]);
amp_bkl=sqrt([bkl_1d(:,1).^2+bkl_1d(:,2).^2,bkl_1d(:,3).^2+bkl_1d(:,4).^2,bkl_1d(:,5).^2+bkl_1d(:,6).^2,...
            bkl_1d(:,7).^2+bkl_1d(:,8).^2,bkl_1d(:,9).^2+bkl_1d(:,10).^2,bkl_1d(:,11).^2+bkl_1d(:,12).^2,...
            bkl_1d(:,1).^2+bkl_1d(:,2).^2+bkl_1d(:,3).^2+bkl_1d(:,4).^2+bkl_1d(:,5).^2+bkl_1d(:,6).^2,...
            bkl_1d(:,7).^2+bkl_1d(:,8).^2+bkl_1d(:,9).^2+bkl_1d(:,10).^2+bkl_1d(:,11).^2+bkl_1d(:,12).^2]);
ph_bkl=rad2deg([atan2(bkl_1d(:,2),bkl_1d(:,1)),atan2(bkl_1d(:,4),bkl_1d(:,3)),atan2(bkl_1d(:,6),bkl_1d(:,5)),...
       atan2(bkl_1d(:,8),bkl_1d(:,7)),atan2(bkl_1d(:,10),bkl_1d(:,9)),atan2(bkl_1d(:,12),bkl_1d(:,11))]);
bkl=[amp_bkl,ph_bkl];

% Eliminate flying-points
x_t=find((xr>-11&xr<-9)|(xr>-1&xr<1)|(xr>9&xr<11));
xr_t=xr; xr_t(x_t)=[];
num_x=length(xr);
num_x_t=length(xr_t);
num_y=length(yr);
num_z=length(zr);
num_polt=num_y*num_z;
amp_1d_t=amp_1d;
ph_1d_t=ph_1d;
data_1d_t=data_1d;
bkl_1d_t=bkl_1d;
bkl_t=bkl;
temp=x_t;
for i=1:num_polt-1
    temp=[temp,x_t+i*num_x];
end
amp_1d_t(temp,:)=[];
ph_1d_t(temp,:)=[];
data_1d_t(temp,:)=[];
bkl_1d_t(x_t,:)=[];
bkl_t(x_t,:)=[];

% Write data to files
for i=1:num_polt
    fid1=fopen(['sagged power lines_',num2str(i),'.dat'],'wt');
    fprintf(fid1,'%s \n','x amp_ex amp_ey amp_ez amp_hx amp_hy amp_hz amp_e amp_h ph_ex ph_ey ph_ez ph_hx ph_hy ph_hz');
    for m=1:num_x_t
        fprintf(fid1,'%f %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e\n',...
                [xr_t(m),amp_1d_t(num_x_t*(i-1)+m,:),ph_1d_t(num_x_t*(i-1)+m,:)]);
    end
    fclose(fid1);
end
fid1=fopen(['straight power lines.dat'],'wt');
fprintf(fid1,'%s \n','x amp_ex amp_ey amp_ez amp_hx amp_hy amp_hz amp_e amp_h ph_ex ph_ey ph_ez ph_hx ph_hy ph_hz');
for m=1:num_x_t
    fprintf(fid1,'%f %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e %15.8e\n',...
                    [xr_t(m),bkl_t(m,:)]);
end
fclose(fid1);


